package com.example.yes.presentation.add_edit_task

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.yes.domain.model.InvalidTaskException
import com.example.yes.domain.model.Task
import com.example.yes.domain.use_case.TasksUseCases
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AddEditViewModel @Inject constructor(
    private val tasksUseCases: TasksUseCases,
    savedStateHandle: SavedStateHandle
):ViewModel(){
    private val _taskTitle = mutableStateOf(
        TaskTextFieldState(
        hint = "Enter a task..."
    )
    )
    val taskTitle: State<TaskTextFieldState> = _taskTitle

    private val isTaskImportant = false

    private val _taskImportance = mutableStateOf(isTaskImportant)

    val taskImportance:State<Boolean> = _taskImportance

     var dateCreated:String = ""



    private val _eventFlow = MutableSharedFlow<UiEvent>()
    val eventFlow = _eventFlow.asSharedFlow()

    private var currentTaskId:Int? = null



    init {
        savedStateHandle.get<Int>("taskId")?.let {taskId->
            if(taskId!=-1){
                viewModelScope.launch {
                    tasksUseCases.getTask(taskId)?.also { task ->
                        currentTaskId = task.id
                        _taskTitle.value = taskTitle.value.copy(
                            text = task.name,
                            isHintVisible = false
                        )
                        dateCreated = task.createdDateFormatted
                        _taskImportance.value = task.important
                    }
                }
            }
        }
    }

    fun onEvent(event: AddEditTaskEvent){
        when(event){
            is AddEditTaskEvent.EnteredTitle ->{
                _taskTitle.value = taskTitle.value.copy(
                    text=event.value
                )
            }
            is AddEditTaskEvent.ChangeTitleFocus ->{
                _taskTitle.value = taskTitle.value.copy(
                    isHintVisible = !event.focusState.isFocused &&
                        taskTitle.value.text.isBlank()
                )
            }
            is AddEditTaskEvent.ImportantChecked ->{
                _taskImportance.value = !_taskImportance.value
            }
            is AddEditTaskEvent.SaveTask ->{
                viewModelScope.launch {
                    try {
                        tasksUseCases.addTask(
                            Task(
                                name = taskTitle.value.text,
                                important = _taskImportance.value,
                                id=currentTaskId
                            )
                        )
                        _eventFlow.emit(UiEvent.SaveTask)
                    }catch (e: InvalidTaskException){
                        _eventFlow.emit(
                            UiEvent.ShowSnackBar(
                                message = e.message ?: "Couldn't save note"
                            )
                        )
                    }
                }
            }
        }
    }


}

sealed class UiEvent{
    data class ShowSnackBar(val message:String): UiEvent()
    object SaveTask: UiEvent()
}