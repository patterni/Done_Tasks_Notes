package com.example.yes.domain.use_case

import com.example.yes.domain.model.InvalidTaskException
import com.example.yes.domain.model.Task
import com.example.yes.domain.repository.TaskRepository

class AddTask (
    private val repository: TaskRepository
){

    @Throws(InvalidTaskException::class)
    suspend operator fun invoke(task: Task){
        if(task.name.isBlank()){
            throw InvalidTaskException("The title of task can't by empty")
        }
        repository.insertTask(task)
    }
}