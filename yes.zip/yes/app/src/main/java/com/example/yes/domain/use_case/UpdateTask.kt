package com.example.yes.domain.use_case

import com.example.yes.domain.repository.TaskRepository

class UpdateTask(private val repository: TaskRepository) {
    suspend operator fun invoke(completed:Boolean, id:Int?){
        repository.updateTask(completed,id)
    }
}