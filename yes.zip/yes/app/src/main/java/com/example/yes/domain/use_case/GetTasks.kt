package com.example.yes.domain.use_case

import com.example.yes.domain.model.Task
import com.example.yes.domain.repository.TaskRepository
import com.example.yes.domain.util.OrderType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class GetTasks(
    private val repository: TaskRepository
) {
    operator fun invoke(orderType: OrderType = OrderType.Descending): Flow<List<Task>> {
        return repository.getTasks().map { tasks->
            when(orderType){
                is OrderType.Ascending ->{
                    tasks.sortedBy {it.created}
                }
                is OrderType.Descending->{
                    tasks.sortedByDescending { it.created }
                }
            }
        }
    }

}