package com.example.yes.presentation.add_edit_task

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.rememberScaffoldState
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material.Scaffold
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.yes.presentation.add_edit_task.components.TransparentHintTextField
import kotlinx.coroutines.flow.collectLatest

@Composable
fun AddEditTask(
    navController: NavController,
    viewModel: AddEditViewModel = hiltViewModel()
){
    val titleState = viewModel.taskTitle.value
    val taskImportance = viewModel.taskImportance.value
    val scaffoldState = rememberScaffoldState()

    val dateCreated = viewModel.dateCreated

    val scope = rememberCoroutineScope()

    LaunchedEffect(key1 = true){
        viewModel.eventFlow.collectLatest { event->
            when(event){
                is UiEvent.ShowSnackBar ->{
                    scaffoldState.snackbarHostState.showSnackbar(
                        message = event.message
                    )
                }
                is UiEvent.SaveTask ->{
                    navController.navigateUp()
                }
            }
        }
    }

    Scaffold (floatingActionButton = {
        ExtendedFloatingActionButton(
            text = {Text("Save")},
            onClick = {viewModel.onEvent(AddEditTaskEvent.SaveTask)},
            modifier = Modifier
                .padding(16.dp),
            icon =  { Icon(imageVector = Icons.Default.Save, contentDescription = "floating action button")}
        )
    }, scaffoldState = scaffoldState
    ){ padding->
        Column (modifier = Modifier.padding(padding)){
            TransparentHintTextField(
                text = titleState.text,
                hint = titleState.hint,
                onValueChange = {
                                viewModel.onEvent(AddEditTaskEvent.EnteredTitle(it))
                },
                onFocusChange = {viewModel.onEvent(AddEditTaskEvent.ChangeTitleFocus(it))},
                isHintVisible = titleState.isHintVisible,
                singleLine =true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp, 16.dp, 16.dp, 8.dp)
            )
            Row(modifier = Modifier.padding(10.dp, 0.dp, 0.dp, 0.dp)) {
                Checkbox(
                    checked = taskImportance,
                    onCheckedChange = {
                                      viewModel.onEvent(AddEditTaskEvent.ImportantChecked(it))
                    },
                )
                Text(
                    text = "Important task",
                    modifier = Modifier.align(Alignment.CenterVertically),
                )
            }
            Text(text = "Date Created: $dateCreated",
                modifier = Modifier.padding(16.dp, 0.dp),
                style = MaterialTheme.typography.bodySmall)
        }

    }



}
