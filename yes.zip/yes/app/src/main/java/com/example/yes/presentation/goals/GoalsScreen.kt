package com.example.yes.presentation.goals

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.yes.presentation.BottomNavigationBar

@Composable
fun Goals(modifier: Modifier = Modifier){
    Box(modifier = modifier.fillMaxSize()){
        Icon(imageVector = Icons.Filled.Face,
            contentDescription ="contacts",
            tint = Color.Blue,
            modifier = Modifier
                .size(150.dp)
                .align(Alignment.Center)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoalsScreen(navController: NavController){
    Scaffold(bottomBar = {BottomNavigationBar(navController = navController)}) {paddingValues ->
        Goals(modifier = Modifier.padding(paddingValues))
    }
}