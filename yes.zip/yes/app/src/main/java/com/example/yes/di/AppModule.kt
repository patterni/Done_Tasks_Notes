package com.example.yes.di

import android.app.Application
import androidx.room.Room
import com.example.yes.data.data_source.TaskDatabase
import com.example.yes.data.repository.TaskRepositoryImpl
import com.example.yes.domain.repository.TaskRepository
import com.example.yes.domain.use_case.AddTask
import com.example.yes.domain.use_case.DeleteTask
import com.example.yes.domain.use_case.GetTask
import com.example.yes.domain.use_case.GetTasks
import com.example.yes.domain.use_case.TasksUseCases
import com.example.yes.domain.use_case.UpdateTask
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(
        app:Application): TaskDatabase {
        return Room.databaseBuilder(
            app, TaskDatabase::class.java,
            TaskDatabase.DATABASE_NAME
        ).build()
    }

    @Provides
    @Singleton
    fun provideNoteRepository(db: TaskDatabase): TaskRepository {
        return TaskRepositoryImpl(db.taskDao)
    }

    @Provides
    @Singleton
    fun provideTaskUseCases(repository: TaskRepository): TasksUseCases {
        return TasksUseCases(
            getTasks = GetTasks(repository),
            deleteTask = DeleteTask(repository),
            addTask = AddTask(repository),
            getTask = GetTask(repository),
            updateTask = UpdateTask(repository)
        )
    }
}