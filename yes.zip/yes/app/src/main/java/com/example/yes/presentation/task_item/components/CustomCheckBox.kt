package com.example.yes.presentation.task_item.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun CustomCheckBox(taskName:String,
                   taskCompleted:Boolean,
                   onCheckedChange:(Boolean)->Unit,
                   modifier: Modifier= Modifier){
    Row(modifier=modifier.padding(10.dp,0 .dp,0 .dp,0 .dp)) {
        Checkbox(checked = taskCompleted,
            onCheckedChange = {
                onCheckedChange(it)
            }, modifier = Modifier.align(Alignment.CenterVertically))
        if(taskCompleted){
            Text(
                text = taskName,
                modifier = Modifier
                    .align(Alignment.CenterVertically),
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = TextStyle(textDecoration = TextDecoration.LineThrough),
            )
        }else {
            Text(
                text = taskName,
                modifier = Modifier
                    .align(Alignment.CenterVertically),
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}

@Preview
@Composable
fun CustomCheckBoxPreview(){
//    CustomCheckBox(taskName = "No task", taskCompleted = false, onCheckedChange = )
}