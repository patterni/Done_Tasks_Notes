package com.example.yes.presentation.tasks

import com.example.yes.domain.model.Task
import com.example.yes.domain.util.OrderType

data class TasksState (
    val tasks:List<Task> = emptyList(),
    val isOrderSectionVisible:Boolean = false,
    val orderType: OrderType = OrderType.Descending
)