package com.example.yes.presentation.util

sealed class Screen(val route:String){
    object GoalsScreen:Screen("goals_screen")
    object ProfileScreen:Screen("profile_screen")
    object BottomBar:Screen("bottom_bar")
    object TasksScreen: Screen("tasks_screen")
    object AddEditTaskScreen: Screen("add_edit_task_screen")


}
