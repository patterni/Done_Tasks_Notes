package com.example.yes.presentation.tasks

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult.ActionPerformed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.yes.presentation.BottomNavigationBar
import com.example.yes.presentation.task_item.TaskItem
import com.example.yes.presentation.tasks.components.OrderSection
import com.example.yes.presentation.util.Screen
import kotlinx.coroutines.launch


@Composable
fun Tasks(
          navController:NavController,
          viewModel: TasksViewModel = hiltViewModel()
) {
    val state = viewModel.state.value
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()


    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
        ExtendedFloatingActionButton(
            text = {Text("Add")},
            onClick = {navController.navigate(Screen.AddEditTaskScreen.route)},
            modifier = Modifier
                .padding(16.dp),
            icon =  { Icon(Icons.Filled.Add, "floating action button") }
        )
    }, bottomBar = { BottomNavigationBar(navController = navController) },) {padding->
        Column (modifier = Modifier
            .padding(padding)){
            IconButton(onClick = {viewModel.onEvent(TasksEvent.ToggleOrderSection)}) {
                Icon(imageVector = Icons.Default.Sort, contentDescription = "Sort")
            }
            AnimatedVisibility(visible = state.isOrderSectionVisible,
                enter = fadeIn() + slideInVertically(),
                exit = fadeOut() + slideOutVertically()) {
               OrderSection(orderType = state.orderType,
                   onOrderChange = {
                       viewModel.onEvent(TasksEvent.Order(it))
                   }, modifier = Modifier
                       .fillMaxWidth()
                       .padding(vertical = 16.dp)
               )
            }
            LazyColumn(modifier = Modifier.fillMaxSize()
                .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.tasks) { task ->
                    var completionState by rememberSaveable { mutableStateOf(task.completed) }
                    TaskItem(task = task,
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable {
                                navController.navigate(
                                    Screen.AddEditTaskScreen.route +
                                            "?taskId=${task.id}"
                                )
                            }, onDeleteClick = {
                            viewModel.onEvent(TasksEvent.DeleteTask(task))
                            scope.launch {
                                val result = snackbarHostState.showSnackbar(
                                    message = "Task deleted",
                                    actionLabel = "Undo"
                                )
                                if (result == ActionPerformed) {
                                    viewModel.onEvent(TasksEvent.RestoreTask)
                                }
                            }
                        }, taskCompleted =completionState ,onCheckedChange = {
                            completionState=it
                            viewModel.onEvent(TasksEvent.CompleteTask(task))
                        }
                    )
                }
            }
        }
    }
}
