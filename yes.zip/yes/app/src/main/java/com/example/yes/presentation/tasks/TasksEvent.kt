package com.example.yes.presentation.tasks

import com.example.yes.domain.model.Task
import com.example.yes.domain.util.OrderType

sealed class TasksEvent{
    data class DeleteTask(val task: Task): TasksEvent()
    data object RestoreTask: TasksEvent()
    data class CompleteTask(val task: Task): TasksEvent()
    data object ToggleOrderSection: TasksEvent()
    data class Order(val orderType: OrderType): TasksEvent()
}
