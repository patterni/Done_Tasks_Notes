package com.example.yes.domain.use_case

data class TasksUseCases (
    val getTasks: GetTasks,
    val deleteTask: DeleteTask,
    val addTask: AddTask,
    val getTask: GetTask,
    val updateTask: UpdateTask
)