package com.example.yes

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import androidx.navigation.navigation
import com.example.yes.presentation.add_edit_task.AddEditTask
import com.example.yes.presentation.goals.GoalsScreen
import com.example.yes.presentation.profile.ProfileScreen
import com.example.yes.presentation.tasks.Tasks
import com.example.yes.presentation.util.Screen



@Composable
fun ToDoApp(navController: NavHostController){
    NavHost(navController = navController,
        startDestination = Screen.BottomBar.route){
        
        navigation(route=Screen.BottomBar.route,
            startDestination =Screen.TasksScreen.route){
            composable(route= Screen.TasksScreen.route){
                Tasks(navController = navController)
            }
            composable(route = Screen.GoalsScreen.route){
                GoalsScreen(navController = navController)
            }
            composable(route = Screen.ProfileScreen.route){
                ProfileScreen(navController = navController)
            }
        }
        composable(route = Screen.AddEditTaskScreen.route +
                "?taskId={taskId}", arguments = listOf(
            navArgument(
                name = "taskId"
            ){
                type = NavType.IntType
                defaultValue = -1
            }
        )
        ){
            AddEditTask(navController = navController)
        }
    }
}